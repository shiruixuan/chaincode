/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// RecordContract contract for managing CRUD for Record
type RecordContract struct {
	contractapi.Contract
}
type QueryResult struct {
	Key  string `json:"Key"`
	Data *Record
}

// RecordExists returns true when asset with given ID exists in world state
func (c *RecordContract) RecordExists(ctx contractapi.TransactionContextInterface, recordID string) (bool, error) {
	data, err := ctx.GetStub().GetState(recordID)

	if err != nil {
		return false, err
	}

	return data != nil, nil
}

// CreateRecord creates a new instance of Record
func (c *RecordContract) CreateRecord(ctx contractapi.TransactionContextInterface, carNum string, value string, recordTime string) error {

	record := new(Record)
	record.Value = value
	record.CarNum = carNum
	loc, _ := time.LoadLocation("Asia/Shanghai")
	time.Local = loc
	_, err := time.ParseInLocation("2006-01-02 15:04:05", recordTime, loc)
	if err != nil {
		return err
	}
	record.RecordTime = recordTime
	key := fmt.Sprintf("%s-%s", carNum, recordTime)
	if err != nil {
		return err
	}
	bytes, _ := json.Marshal(record)

	return ctx.GetStub().PutState(key, bytes)
}

func (c *RecordContract) GetRecordByRange(ctx contractapi.TransactionContextInterface, carNum string, startTime string, endTime string) ([]QueryResult, error) {
	loc, _ := time.LoadLocation("Asia/Shanghai")
	time.Local = loc
	_, err := time.ParseInLocation("2006-01-02 15:04:05", startTime, loc)
	if err != nil {
		return nil, err
	}
	_, err = time.ParseInLocation("2006-01-02 15:04:05", endTime, loc)
	if err != nil {
		return nil, err
	}
	resultsIterator, err := ctx.GetStub().GetStateByRange(fmt.Sprintf("%s-%s", carNum, startTime), fmt.Sprintf("%s-%s", carNum, endTime))
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()
	results := []QueryResult{}
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		record := new(Record)
		_ = json.Unmarshal(queryResponse.Value, record)

		queryResult := QueryResult{Key: queryResponse.Key, Data: record}
		results = append(results, queryResult)
	}

	return results, nil

}

// ReadRecord retrieves an instance of Record from the world state
func (c *RecordContract) ReadRecord(ctx contractapi.TransactionContextInterface, recordID string) (*Record, error) {
	exists, err := c.RecordExists(ctx, recordID)
	if err != nil {
		return nil, fmt.Errorf("Could not read from world state. %s", err)
	} else if !exists {
		return nil, fmt.Errorf("The asset %s does not exist", recordID)
	}

	bytes, _ := ctx.GetStub().GetState(recordID)

	record := new(Record)

	err = json.Unmarshal(bytes, record)

	if err != nil {
		return nil, fmt.Errorf("Could not unmarshal world state data to type Record")
	}

	return record, nil
}

// UpdateRecord retrieves an instance of Record from the world state and updates its value
func (c *RecordContract) UpdateRecord(ctx contractapi.TransactionContextInterface, recordID string, newValue string) error {
	exists, err := c.RecordExists(ctx, recordID)
	if err != nil {
		return fmt.Errorf("Could not read from world state. %s", err)
	} else if !exists {
		return fmt.Errorf("The asset %s does not exist", recordID)
	}

	record := new(Record)
	record.Value = newValue

	bytes, _ := json.Marshal(record)

	return ctx.GetStub().PutState(recordID, bytes)
}

// DeleteRecord deletes an instance of Record from the world state
func (c *RecordContract) DeleteRecord(ctx contractapi.TransactionContextInterface, recordID string) error {
	exists, err := c.RecordExists(ctx, recordID)
	if err != nil {
		return fmt.Errorf("Could not read from world state. %s", err)
	} else if !exists {
		return fmt.Errorf("The asset %s does not exist", recordID)
	}

	return ctx.GetStub().DelState(recordID)
}
