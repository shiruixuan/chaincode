/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

// Record stores a value
type Record struct {
	CarNum string `json:"carNum"`
	RecordTime string `json:"recordTime"`
	Value string `json:"value"`
}
